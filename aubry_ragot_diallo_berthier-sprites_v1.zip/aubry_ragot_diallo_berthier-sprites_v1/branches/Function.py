import os
import time

import pygame
from pygame.locals import *

import Entity.Hero as mHero
import Entity.Ennemis as mEnnemis

@staticmethod
def draw():
    '''
    eaz
    '''
def Resolution(imgPyg):
    img = imgPyg.style
    return img.get_width(), img.get_height()